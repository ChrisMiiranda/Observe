package ecommerce;

public class Cliente implements ICliente{
	private String aviso;
	private String nome;
	
	public Cliente(String nome) {
		this.nome = nome;
	}

	@Override
	public void notifyCliente(Product prod, String siteNome) {
		aviso = "Olá " + this.nome + ", veja só esta novidade: " + prod.getnome() + ". Venha conferir em nosso site " + siteNome;
		System.out.println(aviso);
	}
	
}
