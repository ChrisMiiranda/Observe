package ecommerce;

public interface ICliente {
	
	public void notifyCliente(Product prod, String shopName);
}
