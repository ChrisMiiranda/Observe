package ecommerce;

public interface ILoja {
	void addCliente(Cliente client);
	void desattachCliente(Cliente client);
	void notifyCliente(Product produto);
}
