package ecommerce;

import java.util.ArrayList;
import java.util.List;

public class Loja implements ILoja{
	private String nome;
	private List<Cliente> clientes;
	private List<Product> produtos;
	
	public Loja(String nome) {
		this.nome = nome;
		clientes = new ArrayList<>();
		produtos = new ArrayList<>();
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	public void addProduto(Product produto) {
		produtos.add(produto);
		notifyCliente(produto);
	}
	
	@Override
	public void addCliente(Cliente cus) {
		clientes.add(cus);
	}

	@Override
	public void desattachCliente(Cliente cus) {
		clientes.remove(cus);
	}

	@Override
	public void notifyCliente(Product produto) {
		for(Cliente cus: clientes) {
			cus.notifyCliente(produto, getNome());
		}
		
	}

}
