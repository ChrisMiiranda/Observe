package ecommerce;

public class Main {

	public static void main(String[] args) {
		Loja Kabum = new Loja("Submarino");
		Cliente c1 = new Cliente("Christopher");
		Cliente c2 = new Cliente("Walter");
		Product prod = new Product("Televisão 72' SOny", 2000, "a tv mais fina, leve e macia do mercado");
		
		Kabum.addCliente(c1);
		Kabum.addCliente(c2);
		
		Kabum.addProduto(prod);
	}

}
