package ecommerce;

public class Product {
	private String nome;
	private double preco;
	private String desc;
	
	public Product(String nome, double preco, String desc) {
		this.nome = nome;
		this.preco = preco;
		this.desc = desc;
	}

	public String getnome() {
		return nome;
	}

	public void setnome(String nome) {
		this.nome = nome;
	}

	public double getPreço() {
		return preco;
	}

	public void setPreço(double preco) {
		this.preco = preco;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
