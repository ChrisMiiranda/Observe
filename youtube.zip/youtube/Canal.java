package youtube;

import java.util.ArrayList;
import java.util.List;

public class Canal implements ICanal {
	private List<Inscritos> inscritos;
	private List<Videos> videos;
	private String nome;
	
	public Canal(String nome) {
		this.nome = nome;
		inscritos = new ArrayList();
		videos = new ArrayList();
	}
	
	public void addVideo(String videoName) {
		Videos video = new Videos(videoName);
		videos.add(video);
		notifyInscritos(video);
	}
	
	@Override
	public void notifyInscritos(Videos video) {
		for(Inscritos subs: inscritos ) {
			subs.newVideoAdded(this.nome, video);
		}
		
	}
}
