package youtube;

public interface ICanal {
	void subscribeToChannel(Inscritos ins);
	void unfollowChannel(Inscritos ins);
	void notifyInscritos(Videos video);
}
