package youtube;

public interface IInscritos {
	void newVideoAdded(String channelName, Videos video);
}
