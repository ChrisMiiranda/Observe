package youtube;

public class Inscritos implements IInscritos {
	private String aviso;
	private String nome;
	
	public Inscritos(String nome) {
		this.nome = nome;
	}

	@Override
	public void newVideoAdded(String channelName, Videos video) {
		this.aviso = "Ola "+ this.nome + " o canal " + channelName + " acaba de lançar o video " + video.getTitulo() + " venha conferir!";
		System.out.println(aviso);
	}
	
}
