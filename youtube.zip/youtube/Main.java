package youtube;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Canal newVideo = new Canal("Saiu video novo em!");
		Inscritos i1 = new Inscritos("joaozinho");
		Inscritos i2 = new Inscritos("carlinho");
		Inscritos i3 = new Inscritos("paulinho");
		
	}

}
