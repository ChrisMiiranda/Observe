package youtube;

public class Videos {

	private String titulo;
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Videos(String titulo) {
		this.titulo = titulo;	
	}
}
